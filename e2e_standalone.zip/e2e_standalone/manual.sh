./generateArtifacts.sh mychannel
sudo docker-compose -f docker-compose-cli.yaml up -d
sudo docker exec -it cli bash
